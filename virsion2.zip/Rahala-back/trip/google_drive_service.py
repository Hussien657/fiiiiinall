import os
import io
import json
from typing import Optional, Dict, Any
from django.conf import settings
from django.core.files.uploadedfile import InMemoryUploadedFile, TemporaryUploadedFile
from google.oauth2 import service_account
from googleapiclient.discovery import build
from googleapiclient.http import MediaIoBaseUpload
from googleapiclient.errors import HttpError
import logging

logger = logging.getLogger(__name__)

class GoogleDriveService:
    """Service for handling Google Drive operations"""
    
    def __init__(self):
        self.service = None
        self.folder_id = None
        self._initialize_service()
    
    def _initialize_service(self):
        """Initialize Google Drive service with credentials"""
        try:
            # Get credentials from environment or service account file
            if hasattr(settings, 'GOOGLE_DRIVE_CREDENTIALS_JSON'):
                # If credentials are stored as JSON string in settings
                credentials_info = json.loads(settings.GOOGLE_DRIVE_CREDENTIALS_JSON)
                credentials = service_account.Credentials.from_service_account_info(
                    credentials_info,
                    scopes=['https://www.googleapis.com/auth/drive.file']
                )
            elif hasattr(settings, 'GOOGLE_DRIVE_CREDENTIALS_FILE'):
                # If credentials are stored in a file
                credentials = service_account.Credentials.from_service_account_file(
                    settings.GOOGLE_DRIVE_CREDENTIALS_FILE,
                    scopes=['https://www.googleapis.com/auth/drive.file']
                )
            else:
                raise ValueError("Google Drive credentials not configured")
            
            self.service = build('drive', 'v3', credentials=credentials)
            self.folder_id = getattr(settings, 'GOOGLE_DRIVE_FOLDER_ID', None)
            
            logger.info("Google Drive service initialized successfully")
            
        except Exception as e:
            logger.error(f"Failed to initialize Google Drive service: {str(e)}")
            raise
    
    def create_folder(self, folder_name: str, parent_folder_id: Optional[str] = None) -> str:
        """Create a folder in Google Drive"""
        try:
            folder_metadata = {
                'name': folder_name,
                'mimeType': 'application/vnd.google-apps.folder'
            }
            
            if parent_folder_id:
                folder_metadata['parents'] = [parent_folder_id]
            
            folder = self.service.files().create(body=folder_metadata).execute()
            logger.info(f"Created folder '{folder_name}' with ID: {folder.get('id')}")
            return folder.get('id')
            
        except HttpError as e:
            logger.error(f"Failed to create folder '{folder_name}': {str(e)}")
            raise
    
    def upload_file(self, file_obj, filename: str, folder_id: Optional[str] = None) -> Dict[str, Any]:
        """Upload a file to Google Drive"""
        try:
            # Determine MIME type based on file extension
            mime_type = self._get_mime_type(filename)
            
            # Prepare file content
            if isinstance(file_obj, (InMemoryUploadedFile, TemporaryUploadedFile)):
                file_obj.seek(0)  # Reset file pointer
                file_content = file_obj.read()
                file_obj.seek(0)  # Reset again for potential reuse
            else:
                file_content = file_obj.read()
            
            # Create media upload object
            media = MediaIoBaseUpload(
                io.BytesIO(file_content),
                mimetype=mime_type,
                resumable=True
            )
            
            # File metadata
            file_metadata = {
                'name': filename,
            }
            
            # Set parent folder if specified
            if folder_id or self.folder_id:
                file_metadata['parents'] = [folder_id or self.folder_id]
            
            # Upload file
            file = self.service.files().create(
                body=file_metadata,
                media_body=media,
                fields='id,name,webViewLink,webContentLink,size'
            ).execute()
            
            # Make file publicly viewable
            self._make_file_public(file.get('id'))
            
            # Get public URL
            public_url = self._get_public_url(file.get('id'))
            
            result = {
                'id': file.get('id'),
                'name': file.get('name'),
                'web_view_link': file.get('webViewLink'),
                'web_content_link': file.get('webContentLink'),
                'public_url': public_url,
                'size': file.get('size')
            }
            
            logger.info(f"Successfully uploaded file '{filename}' with ID: {file.get('id')}")
            return result
            
        except HttpError as e:
            logger.error(f"Failed to upload file '{filename}': {str(e)}")
            raise
        except Exception as e:
            logger.error(f"Unexpected error uploading file '{filename}': {str(e)}")
            raise
    
    def _make_file_public(self, file_id: str):
        """Make a file publicly viewable"""
        try:
            permission = {
                'role': 'reader',
                'type': 'anyone'
            }
            self.service.permissions().create(
                fileId=file_id,
                body=permission
            ).execute()
            logger.debug(f"Made file {file_id} publicly viewable")
        except HttpError as e:
            logger.warning(f"Failed to make file {file_id} public: {str(e)}")
    
    def _get_public_url(self, file_id: str) -> str:
        """Get public URL for a file"""
        return f"https://drive.google.com/uc?id={file_id}"
    
    def _get_mime_type(self, filename: str) -> str:
        """Get MIME type based on file extension"""
        extension = os.path.splitext(filename)[1].lower()
        
        mime_types = {
            # Images
            '.jpg': 'image/jpeg',
            '.jpeg': 'image/jpeg',
            '.png': 'image/png',
            '.gif': 'image/gif',
            '.webp': 'image/webp',
            '.bmp': 'image/bmp',
            '.tiff': 'image/tiff',
            
            # Videos
            '.mp4': 'video/mp4',
            '.mov': 'video/quicktime',
            '.avi': 'video/x-msvideo',
            '.mkv': 'video/x-matroska',
            '.webm': 'video/webm',
            '.flv': 'video/x-flv',
            '.wmv': 'video/x-ms-wmv',
        }
        
        return mime_types.get(extension, 'application/octet-stream')
    
    def delete_file(self, file_id: str) -> bool:
        """Delete a file from Google Drive"""
        try:
            self.service.files().delete(fileId=file_id).execute()
            logger.info(f"Successfully deleted file with ID: {file_id}")
            return True
        except HttpError as e:
            logger.error(f"Failed to delete file {file_id}: {str(e)}")
            return False
    
    def get_file_info(self, file_id: str) -> Optional[Dict[str, Any]]:
        """Get information about a file"""
        try:
            file = self.service.files().get(
                fileId=file_id,
                fields='id,name,size,mimeType,webViewLink,webContentLink'
            ).execute()
            return file
        except HttpError as e:
            logger.error(f"Failed to get file info for {file_id}: {str(e)}")
            return None


# Singleton instance
_drive_service = None

def get_drive_service() -> GoogleDriveService:
    """Get or create Google Drive service instance"""
    global _drive_service
    if _drive_service is None:
        _drive_service = GoogleDriveService()
    return _drive_service
